exports.run = async(client, message, args) => {
    const channel = message.member.voice.channel;
    if (!channel) return message.channel.send('Debes unirte a un canal de voz antes de usar este comando!');

    let queue = message.client.queue.get(message.guild.id)

    if(!args[0]) return message.channel.send({
        embed: {
            description: 'El volumen actual está configurado en: ' + queue.volume
        }
    })

    if(args[0] > 10) return message.channel.send('Volumen (1 - 10)')

    queue.connection.dispatcher.setVolumeLogarithmic(args[0] / 5);
    queue.volume = args[0]
    message.channel.send({
        embed: {
            description: 'El volumen está configurado en ' + args[0]
        }
    })
}