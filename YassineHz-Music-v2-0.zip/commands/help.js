exports.run = async(client, message) => {
    message.channel.send({
        embed: {
            title: '**Ayuda 🎶**',
            description: `
            __**Comandos**__
            
            \`play\` <songName> => Reproduce la canción.
            \`pause\` => Pausa.
            \`resume\` => Reanuda.
            \`np\` => Información de la canción.
            \`skip\` => Pasa a la siquiente canción.
            \`stop\` => Para la canción.
            \`volume\` <value> => Ajusta el volumen de la música.
            \`queue\` => Lista de canciónes en cola.


            `,
            color: 'BLACK'
        }
    })
}
