const config = {
    token: 'ODA5MTE1OTU2MzkwNTI3MDI3.YCQZ9A.ktm6N9cM5QHztKtC1w0Q-dJp7rI',
    prefix: '_',
}
module.exports = config;