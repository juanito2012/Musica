const { MessageEmbed } = require('discord.js')

exports.run = async (client, message) => {
    const channel = message.member.voice.channel;
    if (!channel) return message.channel.send('Debes unirte a un canal de voz antes de usar este comando!');
    const queue = message.client.queue.get(message.guild.id)
    let status;
    if(!queue) status = 'No hay nada en la cola!'
    else status = queue.songs.map(x => '• ' + x.title + ' -Añadida por ' + `<@${x.requester.id}>`).join('\n')
    if(!queue) np = status
    else np = queue.songs[0].title
    if(queue) thumbnail = queue.songs[0].thumbnail
    else thumbnail = message.guild.iconURL()
    let embed = new MessageEmbed()
    .setTitle('Cola')
    .setThumbnail(thumbnail)
    .setColor('BLACK')
    .addField('Reproduciendo', np, true)
    .setDescription(status)
    message.channel.send(embed)
}