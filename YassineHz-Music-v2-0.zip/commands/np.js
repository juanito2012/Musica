const { MessageEmbed } = require('discord.js')
exports.run = async(client, message) => {
    const channel = message.member.voice.channel;
    if (!channel) return message.channel.send('Debes unirte a un canal de voz antes de usar este comando!');
    let queue = message.client.queue.get(message.guild.id)
    if(!queue) return message.channel.send({
        embed:{
            title: 'No se está reproduciendo nada en este momento!'
        }
    })
    message.channel.send({
        embed:{
            title: 'Reproduciendo',
            description: queue.songs[0].title + ' Añadido por: ' + '<@' + queue.songs[0].requester + '>',
            color: 'BLACK',
            thumbnail: queue.songs[0].thumbnail
        }
    })
}