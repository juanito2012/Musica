module.exports = (client) => {
    console.log('Login as' + client.user.tag)
    console.log(`YassineHz ©`);
    console.log(`YassineHz ©`);
    console.log(`YassineHz ©`);
    console.log(`YassineHz ©`);
    console.log(`YassineHz ©`);
    console.log(`YassineHz ©`);
    console.log(`YassineHz ©`);
    console.log(`YassineHz ©`);
    console.log(`YassineHz ©`);
    console.log(`YassineHz ©`);
    console.log(`YassineHz ©`);
    console.log(`YassineHz ©`);
    console.log(`YassineHz ©`);
    console.log(`YassineHz ©`);
}