const express = require("express");///////////YassineHz ©
const app = express();///////////YassineHz ©

app.listen(() => console.log('YassineHz Bot Ready !'));

app.use('/ping', (req, res) => {
  res.send(new Date());///////////YassineHz ©
});

const Discord = require("discord.js");///////////YassineHz ©
const fs = require("fs");///////////YassineHz ©

const client = new Discord.Client();///////////YassineHz ©
const config = require("./config.js");
client.config = config;
client.queue = new Map()///////////YassineHz ©

fs.readdir("./events/", (err, files) => {
  if (err) return console.error(err);///////////YassineHz ©
  files.forEach(file => {
    const event = require(`./events/${file}`);///////////YassineHz ©
    let eventName = file.split(".")[0];///////////YassineHz ©
    client.on(eventName, event.bind(null, client));
  });
});///////////YassineHz ©

client.commands = new Discord.Collection()

fs.readdir("./commands/", (err, files) => {
  if (err) return console.error(err);///////////YassineHz ©
  files.forEach(file => {
    if (!file.endsWith(".js")) return;
    let props = require(`./commands/${file}`);
    let commandName = file.split(".")[0];///////////YassineHz ©
    console.log(`${commandName} Is Ready Now..`);
    client.commands.set(commandName, props);
  });///////////YassineHz ©
});


client.login(config.token);